export const environment = {
  production: true,
  apiUrl: 'http://PW7AM1XDH402918:8080/ssp',
  app_name: 'Self Service Portal',
  url: 'http://localhost:1515',
  isApiReady: true,
  token: "Bearer eyJ1c2VyX2lkIjoiNWFlMTg4ZDZmNGU0Mz.eyJ1c2VyX2lkIjoiNWFlMTg4ZDZmNGU0Mz" +
  "kxZjI0ZTZhYzEwIiwiaWF0IjoxNTI1MjY0NzE4LCJleHAiOjE1MjUyNzQ3MTh9." +
  "1HZBpHcFgTu1ltAYMHz0eKqRlUWYEomjat696Q7G3Sc"
};
