import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateTestMachineComponent } from './update-test-machine.component';

describe('UpdateTestMachineComponent', () => {
  let component: UpdateTestMachineComponent;
  let fixture: ComponentFixture<UpdateTestMachineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateTestMachineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateTestMachineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
