import { Component, OnInit, Inject,Input } from '@angular/core';
import { LoaderService } from '../../../../services/loader.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ApplicationModel } from '../../../../models/application.model';
import { Util } from '../../../../helpers/util.helper';
import { TestCaseModel } from '../../../../models/test-case.model';
import { FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-update-test-machine',
  templateUrl: './update-test-machine.component.html',
  styleUrls: ['./update-test-machine.component.scss']
})
export class UpdateTestMachineComponent implements OnInit {
  @Input() machineObj: any;
  machineDataObj: any = {};
  testMacineName: any;
  applicationType: object;
  apptypeList: any;
  executionStatus: any =[{
    'name' : 'Available',
    'value' : 'Available'
  },
    {
      'name' : 'Running',
      'value' : 'Running'
   }];
  type: any;
  vdiStatus: any =[{
    'name' : 'INACTIVE',
    'value' : 'INACTIVE'
  },
    {
      'name' : 'ACTIVE',
      'value' : 'ACTIVE'
   }];
  constructor(private loaderService: LoaderService,
    public dialogRef: MatDialogRef<UpdateTestMachineComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    TestMachineForm = new FormGroup ({
      testMacineName: new FormControl({value: this.data.machineObj.vdiName, disabled: true}),
      applicationType: new FormControl(this.data.machineObj.applicationType, [Validators.required]),
      vdiStatus: new FormControl(this.data.machineObj.vdiStatus, [Validators.required]),
      ExeStatus: new FormControl({value: this.data.machineObj.runningJobCount, disabled: true}),
    })

    async ngOnInit() {
      // console.log(this.data.machineObj);
      this.machineDataObj = this.data.machineObj;
      if (this.data.machineObj.runningJobCount == 0) {
        this.machineDataObj.executionStatus = 'Available';
      } else {
        this.machineDataObj.executionStatus = 'Running';
      }
       this.apptypeList = await ApplicationModel.getAllApplicationTypeList();
    }
  getInputErrorMessage(input_name: string) {
    let err_message = '';
    if (this.TestMachineForm.get(input_name).hasError('required')) {
      if (input_name === 'ExeStatus') {
        err_message = 'You must select execution status.';
      } else {
        if (input_name === 'vdiStatus') {
          err_message = 'You must select vdi status.';
      } else {
        err_message = 'application type can not be empty';
      }
     } 
    }
    if (this.TestMachineForm.get(input_name).hasError('custom')) {
      err_message = this.TestMachineForm.get(input_name).getError('custom');
    }

    return err_message;
  }
  closeDialog() {
    this.dialogRef.close();
  }

  async updateTestMachine(val: any) {
    // console.log(val);
    // if (val.executionStatus == 'Available') {
    //   val.runningJobCount = 0;
    // } else {
    //   val.runningJobCount = 1;
    // }
    this.loaderService.display(true);
    let err, res;
    [err, res] = await Util.to(TestCaseModel.updateTestMachines(val));
    if (!err) {
      this.loaderService.display(false);
    } else {
      this.loaderService.display(false);
    }
    this.dialogRef.close();

    // console.log(val);
  }

}
