import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestMachineComponent } from './test-machine.component';

describe('TestMachineComponent', () => {
  let component: TestMachineComponent;
  let fixture: ComponentFixture<TestMachineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestMachineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestMachineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
