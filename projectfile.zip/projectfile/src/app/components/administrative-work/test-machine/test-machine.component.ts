import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { TestCaseModel } from '../../../models/test-case.model';
import { LoaderService } from '../../../services/loader.service';
import { JobsModel } from '../../../models/jobs.model';
import { MatDialog } from '@angular/material';
import { ProjectModel } from '../../../models/project.model';
import { DashBoardModel } from '../../../models/dashboard.model';
import { Util } from '../../../helpers/util.helper';
import { UpdateTestMachineComponent } from './update-test-machine/update-test-machine.component';
import { AddTestMachineComponent } from './add-test-machine/add-test-machine.component';
import { DeleteTestMachineComponent } from './delete-test-machine/delete-test-machine.component';


@Component({
  selector: 'app-test-machine',
  templateUrl: './test-machine.component.html',
  styleUrls: ['./test-machine.component.scss']
})
export class TestMachineComponent implements OnInit {
  tempProjectData: any;
  testMachinesList: any;
  testMachinesData: any;
  selectedproValue: any;
  temp = [];
  constructor(public dialog: MatDialog, private loaderService: LoaderService) { }

  async ngOnInit() {
    this.tempProjectData = await DashBoardModel.getAllProjectsList();
    this.loaderService.display(true);
    let err;
    this.getVDIList();
    /* this.testMachinesList = await TestCaseModel.getTestMachineList();
    // this.temp = [...this.testMachinesList];
    this.testMachinesData = this.testMachinesList.data; */
    // this.loaderService.display(false);
    // console.log(this.testMachinesList.data);
  }
  async getVDIList() {
    this.testMachinesList = await TestCaseModel.getTestMachineList();
    // this.temp = [...this.testMachinesList];
    this.testMachinesData = this.testMachinesList.data;
    this.loaderService.display(false);
  }
  openUpdateDialog(element) {
    const dialogRef = this.dialog.open(UpdateTestMachineComponent, {
      width: '350px',
      data: { machineObj: element }
    });
    dialogRef.afterClosed().subscribe(result => {
    });
  }
  openAddDialog(element) {
    const dialogRef = this.dialog.open(AddTestMachineComponent, {
      width: '350',
      data: { machineObj: element }
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.loaderService.display(true);
      TestCaseModel.getTestMachineList().then((data) => {
        if (data) {
          this.testMachinesList = data;
          this.testMachinesData = data.data;
          // this.temp = [...data];
          // this.dataSource = new MatTableDataSource(data);
          this.loaderService.display(false);
        }
      });
    });
  }
  async deleteTestMachine(val: any) {
    const dialogRef = this.dialog.open(DeleteTestMachineComponent, {
      width: '350',
      data: { machineObj: val }
    });
    dialogRef.afterClosed().subscribe((result) => {
      this.getVDIList();
    });


    // if (confirm('Are you sure to delete VDI?')) {
    //   this.loaderService.display(true);
    //   let err, res;
    //   [err, res] = await Util.to(TestCaseModel.deleteTestMachines(val));
    //   if (!err) {
    //     this.loaderService.display(false);
    //     alert('VDI deleted successfully');
    //     this.getVDIList();
    //   } else {
    //     this.loaderService.display(false);
    //   }
    // }
  }

}
