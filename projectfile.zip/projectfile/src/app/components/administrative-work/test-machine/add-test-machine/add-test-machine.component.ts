import { Component, OnInit, Inject, Input } from '@angular/core';
import { LoaderService } from '../../../../services/loader.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TestCaseModel } from '../../../../models/test-case.model';
import { Util } from '../../../../helpers/util.helper';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ApplicationModel } from '../../../../models/application.model';
@Component({
  selector: 'app-add-test-machine',
  templateUrl: './add-test-machine.component.html',
  styleUrls: ['./add-test-machine.component.scss']
})
export class AddTestMachineComponent implements OnInit {
  @Input() machineObj: any;
  machineDataObj: any = {};
  testMacineName: any;
  apptypeList: any;
  // executionStatus: any =[{
  //   'name' : 'Available',
  //   'value' : 'Available'
  // },
  //   {
  //     'name' : 'Running',
  //     'value' : 'Running'
  //  }];
  type: any;
  vdiStatus: any =[{
    'name' : 'INACTIVE',
    'value' : 'INACTIVE'
  },
    {
      'name' : 'ACTIVE',
      'value' : 'ACTIVE'
   }];
  constructor(private loaderService: LoaderService,
    public dialogRef: MatDialogRef<AddTestMachineComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    TestMachineForm = new FormGroup ({
      testMacineName: new FormControl('',[Validators.required]),
      type: new FormControl(this.data.machineObj.applicationType, [Validators.required]),
      vdiStatus: new FormControl('', [Validators.required]),
      // ExeStatus: new FormControl('', [Validators.required]),
    })

    async ngOnInit() {
      // console.log(this.data.machineObj);
      // this.machineDataObj = this.data.machineObj;
      // if (this.data.machineObj.runningJobCount == 1) {
      //   this.machineDataObj.machineStatus = 'Not Available';
      // } else {
      //   this.machineDataObj.machineStatus = 'Available';
      // }
       this.apptypeList = await ApplicationModel.getAllApplicationTypeList();
    }
  getInputErrorMessage(input_name: string) {
    let err_message = '';
    if (this.TestMachineForm.get(input_name).hasError('required')) {
      if (input_name === 'testMacineName') {
        err_message = 'Test Machine Name can not be empty.';
      } else {
          if (input_name === 'vdiStatus') {
            err_message = 'You must select vdi status.';
        } else
        err_message = 'application type can not be empty';
      }
    }
    if (this.TestMachineForm.get(input_name).hasError('custom')) {
      err_message = this.TestMachineForm.get(input_name).getError('custom');
    }

    return err_message;
  }
  closeDialog() {
    this.dialogRef.close();
  }

  async addTestMachine(val: any) {
    // console.log(val);
    if (val.machineStatus == 'Available') {
      val.runningJobCount = 0;
    } else {
      val.runningJobCount = 1;
    }
    this.loaderService.display(true);
    let err, res;
    [err, res] = await Util.to(TestCaseModel.AddNewTestMachine(val));
    if (!err) {
      this.loaderService.display(false);
    } else {
      this.loaderService.display(false);
    }
    this.dialogRef.close();

    // console.log(val);
  }

}
