import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTestMachineComponent } from './add-test-machine.component';

describe('AddTestMachineComponent', () => {
  let component: AddTestMachineComponent;
  let fixture: ComponentFixture<AddTestMachineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddTestMachineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddTestMachineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
