import { Component, OnInit, Inject, Input } from '@angular/core';
import { LoaderService } from '../../../../services/loader.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { TestCaseModel } from '../../../../models/test-case.model';
import { Util } from '../../../../helpers/util.helper';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ApplicationModel } from '../../../../models/application.model';
@Component({
  selector: 'app-delete-test-machine',
  templateUrl: './delete-test-machine.component.html',
  styleUrls: ['./delete-test-machine.component.scss']
})
export class DeleteTestMachineComponent implements OnInit {
  @Input() machineObj: any;
  machineDataObj: any = {};
  testMacineName: any;

  constructor(private loaderService: LoaderService,
    public dialogRef: MatDialogRef<DeleteTestMachineComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  TestMachineForm = new FormGroup({
    testMacineName: new FormControl('', [Validators.required])
  })

  async ngOnInit() {
    // console.log(this.data.machineObj);
    this.machineDataObj = this.data.machineObj;
    if (this.data.machineObj.runningJobCount == 1) {
      this.machineDataObj.machineStatus = 'Not Available';
    } else {
      this.machineDataObj.machineStatus = 'Available';
    }
    // this.apptypeList = await ApplicationModel.getAllApplicationTypeList();
  }
  getInputErrorMessage(input_name: string) {
    let err_message = '';
    if (this.TestMachineForm.get(input_name).hasError('required')) {
      if (input_name === 'testMacineName') {
        err_message = 'Test Machine Name can not be empty.';
      } else {
        if (input_name === 'ExeStatus') {
          err_message = 'You must select execution status.';
        } else {
          if (input_name === 'vdiStatus') {
            err_message = 'You must select vdi status.';
          } else
            err_message = 'application type can not be empty';
        }
      }
    }
    if (this.TestMachineForm.get(input_name).hasError('custom')) {
      err_message = this.TestMachineForm.get(input_name).getError('custom');
    }

    return err_message;
  }
  closeDialog() {
    this.dialogRef.close();
  }

  async addTestMachine(val: any) {
    // if (val.machineStatus == 'Available') {
    //   val.runningJobCount = 0;
    // } else {
    //   val.runningJobCount = 1;
    // }
    this.loaderService.display(true);
    let err, res;
    [err, res] =  await Util.to(TestCaseModel.deleteTestMachines(val));
    if (!err) {
      this.loaderService.display(false);
    } else {
      this.loaderService.display(false);
    }
    this.dialogRef.close();

    // console.log(val);
  }

}
