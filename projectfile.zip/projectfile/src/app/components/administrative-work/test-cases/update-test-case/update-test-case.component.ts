import { Component, OnInit, Inject,Input } from '@angular/core';
import { LoaderService } from '../../../../services/loader.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ApplicationModel } from '../../../../models/application.model';
import { Util } from '../../../../helpers/util.helper';
import { TestCaseModel } from '../../../../models/test-case.model';
import { FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'ssp-update-test-case',
  templateUrl: './update-test-case.component.html',
  styleUrls: ['./update-test-case.component.scss']
})
export class UpdateTestCaseComponent implements OnInit {
  // @Input() machineObj: any;
  // machineDataObj: any = {};
  // testMacineName: any;
  // apptypeList: any;
  // machineStatus: any =[{
  //   'name' : 'Available',
  //   'value' : 'Available'
  // },
  //   {
  //     'name' : 'Not Available',
  //     'value' : 'Not Available'
  //  }];
  // type: any;
  constructor(private loaderService: LoaderService,
    public dialogRef: MatDialogRef<UpdateTestCaseComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

    // TestMachineForm = new FormGroup ({
    //   testMacineName: new FormControl({value: this.data.machineObj.vdiName, disabled: true}),
    //   type: new FormControl(this.data.machineObj.applicationType, [Validators.required]),
    //   status: new FormControl(this.data.machineObj.runningJobCount, [Validators.required]),
    // })

    async ngOnInit() {
      // console.log(this.data.machineObj);
      // this.machineDataObj = this.data.machineObj;
      // if (this.data.machineObj.runningJobCount == 1) {
      //   this.machineDataObj.machineStatus = 'Not Available';
      // } else {
      //   this.machineDataObj.machineStatus = 'Available';
      // }
      //  this.apptypeList = await ApplicationModel.getAllApplicationTypeList();
    }
  // getInputErrorMessage(input_name: string) {
  //   let err_message = '';
  //   if (this.TestMachineForm.get(input_name).hasError('required')) {
  //     if (input_name === 'status') {
  //       err_message = 'You must select status.';
  //     } else {
  //       err_message = 'application type can not be empty';
  //     }
  //   }
  //   if (this.TestMachineForm.get(input_name).hasError('custom')) {
  //     err_message = this.TestMachineForm.get(input_name).getError('custom');
  //   }

  //   return err_message;
  // }
  // closeDialog() {
  //   this.dialogRef.close();
  // }

  // async updateTestMachine(val: any) {
  //   // console.log(val);
  //   if (val.machineStatus == 'Available') {
  //     val.runningJobCount = 0;
  //   } else {
  //     val.runningJobCount = 1;
  //   }
  //   this.loaderService.display(true);
  //   let err, res;
  //   [err, res] = await Util.to(TestCaseModel.updateTestMachines(val));
  //   if (!err) {
  //     this.loaderService.display(false);
  //   } else {
  //     this.loaderService.display(false);
  //   }
  //   this.dialogRef.close();

  //   // console.log(val);
  // }
}
