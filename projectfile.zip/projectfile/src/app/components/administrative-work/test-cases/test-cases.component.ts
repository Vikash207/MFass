import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { TestCaseModel } from '../../../models/test-case.model';
import { LoaderService } from '../../../services/loader.service';
import { JobsModel } from '../../../models/jobs.model';
import { MatDialog } from '@angular/material';
import { AddTestCaseComponent } from './add-test-case/add-test-case.component';
import { UpdateTestCaseComponent } from './update-test-case/update-test-case.component';
import { ProjectModel } from '../../../models/project.model';
import { DashBoardModel } from '../../../models/dashboard.model';
import { Util } from '../../../helpers/util.helper';

@Component({
  selector: 'ssp-test-cases',
  templateUrl: './test-cases.component.html',
  styleUrls: ['./test-cases.component.scss']
})
export class TestCasesComponent implements OnInit {
  // tempProjectData:any;
  // testMachinesList: any;
  // testMachinesData:any;
  // selectedproValue: any;
  // temp = [];
  constructor(public dialog: MatDialog, private loaderService: LoaderService) { }

  async ngOnInit() {
    // this.tempProjectData = await DashBoardModel.getAllProjectsList();
    // let err;
    // this.loaderService.display(true);
    // this.getVDIList();
    // /* this.testMachinesList = await TestCaseModel.getTestMachineList();
    // // this.temp = [...this.testMachinesList];
    // this.testMachinesData = this.testMachinesList.data; */
    // this.loaderService.display(false);
    // // console.log(this.testMachinesList.data);
  }
  // async getVDIList() {
  //   this.testMachinesList = await TestCaseModel.getTestMachineList();
  //   // this.temp = [...this.testMachinesList];
  //   this.testMachinesData = this.testMachinesList.data;
  // }
  // openUpdateDialog(element) {
  //     const dialogRef = this.dialog.open(UpdateTestCaseComponent, {
  //     width: '350px',
  //     data: { machineObj: element }
  //   });
  //   dialogRef.afterClosed().subscribe(result => {
  //   });
  // }
  // openAddDialog(element) {
  //   const dialogRef = this.dialog.open(AddTestCaseComponent, {
  //     width: '350',
  //   data: {machineObj: element}
  // });
  // dialogRef.afterClosed().subscribe((result) => {
  //   this.loaderService.display(true);
  //   TestCaseModel.getTestMachineList().then((data) => {
  //    if (data) {
  //     console.log(data);
     
  //      this.testMachinesList = data;
  //      this.testMachinesData = data.data;
  //      console.log(this.testMachinesList);
  //     // this.temp = [...data];
  //      // this.dataSource = new MatTableDataSource(data);
  //      this.loaderService.display(false);
  //    }
  //   });
  // });
  // }
  // async deleteTestMachine(val: any) {
  //   if(confirm('Are You Sure to Delete VDI?')){
  //   this.loaderService.display(true);
  //   let err, res;
  //   [err, res] = await Util.to(TestCaseModel.deleteTestMachines(val));
  //   if (!err) {
  //     this.loaderService.display(false);
  //     alert('VDI deleted successfully');
  //     this.getVDIList();
  //   } else {
  //     this.loaderService.display(false);
  //   }
  // }
  // }
}
