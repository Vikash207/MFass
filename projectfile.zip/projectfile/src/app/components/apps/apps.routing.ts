import { Routes } from '@angular/router';
export const AppsRoutes: Routes = [{
  path: '',
  children: []
}];


