import { Injectable } from '@angular/core';

@Injectable()
export class DataStorageService {
  public data: any;
  public constructor() { }
}
