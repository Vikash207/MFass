export interface JobsList {
  name?: string,
  description?: string,
  id?:number,
  startDate?: any,
  endDate?: any,
  duration?: any
}
