export interface User {
  emailId?: string,
  phone?: string,
  newPassword?: string,
  firstName?: string,
  lastName?: string,
  auth?: boolean,
  token?: string,
  data?: any
}
